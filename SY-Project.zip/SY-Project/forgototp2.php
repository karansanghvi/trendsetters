<?php
if(isset($_POST['verify'])){
    $email = $_POST['email'];
    $otp = $_POST['otp'];
    
    //check if entered OTP is correct
    if($otp == $_POST['otp']){
        // echo "OTP verified successfully. You can now proceed to the dashboard.";
        header("Location: newpassword.html");
    } else {
        echo "Incorrect OTP. Please try again.";
    }
}
?>