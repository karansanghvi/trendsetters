    <?php

    require_once __DIR__ . '/vendor/autoload.php'; // Load the Twilio PHP library
    use Twilio\Rest\Client;

    $accountSid = 'AC106604825b228f8c1c055049f4ef8abe'; // Your Twilio account SID
    $authToken = '488bd5248bc1b67592e884ec0602af3e'; // Your Twilio auth token
    $twilioNumber = '+15855172600'; // Your Twilio phone number

    $client = new Client ($accountSid, $authToken); // Create a new Twilio client instance

    $phone = $_POST['phone']; // Get the phone number from the form inp
    $message = "Hello Customer!\nYour product will arrive on 4th May by 9:00 a.m. on your registered address!\nThank you for shopping! Visit Again!";
    echo $message;

    // Send the SMS using the Twilio API
    $message = $client->messages->create(
        $phone, // The phone number to send the message to
        array(
            'from' => $twilioNumber,
            'body' => $message
        )
    );

    //echo'alert("Message sent successfully!")'; // Output a success message
    header("Location: index.html");

    ?>
