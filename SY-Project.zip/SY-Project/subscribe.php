<?php
$servername = "localhost";
$username = "nurture_karan";
$password = "UuJ-_Mg)*LVu";
$dbname = "nurture_karan";

$conn = new mysqli($servername,$username,$password,$dbname);

if($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$email = $_POST["email"];

// Insert email into subscribe table
$sql = "INSERT INTO subscribe (email) VALUES ('$email')";
if (!$conn->query($sql)) {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$to_email = $_POST["email"];
$subject = "Trendsetters - Where Style Meets Fashion!";
$body = "Hello, you have successfully subscribed to our email! You will receive the future notifications!";
$headers = "From: trendsetters464@gmail.com";
 
if (mail($to_email, $subject, $body, $headers))
 
{
    // echo "Email successfully sent to $to_email...";
    header("Location: index.html");
    exit();
}
 
else
 
{
    echo "Email sending failed!";
}
?>