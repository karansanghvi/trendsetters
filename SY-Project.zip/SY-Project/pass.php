<?php
if(isset($_POST['submit'])){
    $password = $_POST['password'];
    
    //check if entered OTP is correct
    if($password == $_POST['password']){
        // echo "OTP verified successfully. You can now proceed to the dashboard.";
        header("Location: signup.html");
    } else {
        echo "Incorrect OTP. Please try again.";
    }
}
?>