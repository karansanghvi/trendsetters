'use strict';



/**
 * Mobile navbar toggle
 */

const navbar = document.querySelector("[data-navbar]");
const navToggler = document.querySelector("[data-nav-toggler]");

navToggler.addEventListener("click", function () {
  navbar.classList.toggle("active");
});



/**
 * Header active
 */

const header = document.querySelector("[data-header]");

window.addEventListener("scroll", function () {
  header.classList[this.scrollY > 50 ? "add" : "remove"]("active");
});





function saveFormData() {
  var fname = document.getElementById("fname").value;
  var lname = document.getElementById("lname").value;
  var address1 = document.getElementById("address1").value;
  var landmark = document.getElementById("landmark").value;
  var city = document.getElementById("city").value;
  var state = document.getElementById("state").value;
  var zip = document.getElementById("zip").value;
  localStorage.setItem("fname", fname);
  localStorage.setItem("lname", lname);
  localStorage.setItem("address1", address1);
  localStorage.setItem("landmark", landmark);
  localStorage.setItem("city", city);
  localStorage.setItem("state", state);
  localStorage.setItem("zip", zip);
}