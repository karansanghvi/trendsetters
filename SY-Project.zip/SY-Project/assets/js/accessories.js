'use strict';



/**
 * Mobile navbar toggle
 */

const navbar = document.querySelector("[data-navbar]");
const navToggler = document.querySelector("[data-nav-toggler]");

navToggler.addEventListener("click", function () {
  navbar.classList.toggle("active");
});



/**
 * Header active
 */

const header = document.querySelector("[data-header]");

window.addEventListener("scroll", function () {
  header.classList[this.scrollY > 50 ? "add" : "remove"]("active");
});

// toggle between images in the product page
const sliderMainImage = document.getElementById("MainImage");
const sliderImageList = document.getElementsByClassName("small-img");
console.log(sliderImageList);

sliderImageList[0].onclick = function(){
    sliderMainImage.src = sliderImageList[0].src;
    console.log(sliderMainImage.src);
};

sliderImageList[1].onclick = function(){
    sliderMainImage.src = sliderImageList[1].src;
    console.log(sliderMainImage.src);
};

sliderImageList[2].onclick = function(){
    sliderMainImage.src = sliderImageList[2].src;
    console.log(sliderMainImage.src);
};

sliderImageList[3].onclick = function(){
    sliderMainImage.src = sliderImageList[3].src;
    console.log(sliderMainImage.src);
};


function addToCart() {
  alert('Product Added To The Cart');
  // get the product image source of the main image
  var productImageSrc = document.getElementById('MainImage').src;

  // get the product title
  var productTitle = document.getElementById('product-name').textContent;

  // get the product price
  var productPrice = document.getElementById('price-title').textContent;

  // get the quantity of the product and convert it to a number
  var productQuantity = parseInt(document.getElementById('quantity').value);

  // get the existing cart items from local storage or initialize an empty array
  var cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];

  // create a cart item object with the saved data
  var cartItem = {
    productImageSrc: productImageSrc,
    productTitle: productTitle,
    productPrice: productPrice,
    productQuantity: productQuantity
  };

  // add the cart item object to the cart items array
  cartItems.push(cartItem);

  // save the updated cart items array in local storage
  localStorage.setItem('cartItems', JSON.stringify(cartItems));

  // calculate subtotal and total cost of items in cart
  // calculateCartTotal(cartItems);

  // navigate to the cart page
  window.location.href = 'cart.html';
}
