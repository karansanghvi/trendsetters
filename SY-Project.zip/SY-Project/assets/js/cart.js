// retrieve cart items from local storage or initialize an empty array
var cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];

var totalPrice = 0;

// loop through the cart items and create a table row element for each item
cartItems.forEach(function(cartItem, index) { // add index parameter
  // create a table row element for the new cart item
  var tableRow = document.createElement('tr');

  // for the image
  var tableImageCell = document.createElement('td');
  var tableImage = document.createElement('img');
  tableImage.src = cartItem.productImageSrc;
  tableImageCell.appendChild(tableImage);
  tableRow.appendChild(tableImageCell);

  // for the product title
  var tableTitleCell = document.createElement('td');
  tableTitleCell.textContent = cartItem.productTitle;
  tableRow.appendChild(tableTitleCell);

  // for the product price
  var tablePriceCell = document.createElement('td');
  tablePriceCell.textContent = cartItem.productPrice;
  tableRow.appendChild(tablePriceCell);

  // for the product size
  var tableSizeCell = document.createElement('td');
  tableSizeCell.textContent = cartItem.selectedSize;
  tableRow.appendChild(tableSizeCell);

  // for the product quantity
  var tableQuantityCell = document.createElement('td');
  tableQuantityCell.textContent = cartItem.productQuantity;
  tableRow.appendChild(tableQuantityCell);

  //for price totalling
  totalPrice += parseInt(cartItem.productPrice.substring(1)) * parseInt(cartItem.productQuantity);

  // for the remove button
  var tableRemoveCell = document.createElement('td');
  var removeButton = document.createElement('button');
  removeButton.textContent = 'Remove';
  removeButton.addEventListener('click', function() {
    // remove the cart item from the array
    cartItems.splice(index, 1);
    // update the cart items in local storage
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    // remove the table row from the table body
    tableRow.remove();
  });

  localStorage.setItem('totalPrice', JSON.stringify(totalPrice));


  tableRemoveCell.appendChild(removeButton);
  tableRow.appendChild(tableRemoveCell);

  // add the table row to the table body
  var cartTableBody = document.getElementById('cart-table-body');
  cartTableBody.appendChild(tableRow);
});

document.getElementById("cart-total").innerHTML = document.getElementById("cart-total").innerHTML + ""+ totalPrice;
document.getElementById("cart-subtotal").innerHTML = document.getElementById("cart-subtotal").innerHTML + ""+ totalPrice;
      